"use client";

import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { use } from "react";
import { useTutorialStore } from "@/lib/stores/tutorialStore";
import { HelpTooltip } from "@/components/ui/help-tooltip";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { StatCard } from "@/components/ui/stat-card";
import { formatCurrency } from "@/lib/utils";
import { EnhancedProgress } from "@/components/ui/enhanced-progress";
import { PageHeader } from "@/components/ui/section-header";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/api/trpc";
import { useDecisionStore } from "@/lib/stores/decisionStore";
import { DecisionSubmitBar } from "@/components/game/DecisionSubmitBar";
import { DecisionImpactPanel } from "@/components/game/DecisionImpactPanel";
import { WarningBanner } from "@/components/game/WarningBanner";
import { GamePageSkeleton } from "@/components/game/GamePageSkeleton";
import { ModuleRecap } from "@/components/game/ModuleRecap";
import { useMarketingPreview } from "@/lib/hooks/useMarketingPreview";
import { BRAND_ACTIVITY_MAP } from "@/lib/converters/decisionConverters";
import { useCrossModuleWarnings } from "@/lib/hooks/useCrossModuleWarnings";
import { TeamState, Segment } from "@/engine/types";
import { toast } from "sonner";
import {
  Megaphone,
  TrendingUp,
  Target,
  Award,
  DollarSign,
  Tv,
  Globe,
  Users,
  Star,
  BarChart3,
  Tag,
  Gift,
  Percent,
  AlertTriangle,
  Eye,
  ShoppingCart,
} from "lucide-react";

interface PageProps {
  params: Promise<{ gameId: string }>;
}

// Default marketing data (used when state is not available)
const defaultMarketing = {
  brandValue: 0.5,
  brandAwareness: 45,
  marketShare: 0,
  customerSatisfaction: 70,
  advertisingBudget: 0,
  currentCampaigns: [] as Array<{
    id: string;
    name: string;
    type: string;
    segment: string;
    budget: number;
    reach: number;
    status: string;
  }>,
};

const segments = [
  { id: "Budget", name: "Budget", description: "Price-conscious consumers", icon: Tag },
  { id: "General", name: "General", description: "Mainstream market", icon: Users },
  { id: "Enthusiast", name: "Enthusiast", description: "Tech-savvy users", icon: Star },
  { id: "Professional", name: "Professional", description: "Business & power users", icon: Award },
  { id: "Active Lifestyle", name: "Active Lifestyle", description: "Fitness & outdoor focused", icon: Target },
];

const advertisingChannels = [
  {
    id: "tv",
    name: "Television",
    icon: Tv,
    cpm: 25,
    reach: "High",
    description: "Broad reach, brand building",
    effectiveness: { Budget: 0.6, General: 0.9, Enthusiast: 0.5, Professional: 0.4, "Active Lifestyle": 0.7 },
  },
  {
    id: "digital",
    name: "Digital Ads",
    icon: Globe,
    cpm: 8,
    reach: "Targeted",
    description: "Precise targeting, measurable ROI",
    effectiveness: { Budget: 0.8, General: 0.8, Enthusiast: 0.95, Professional: 0.85, "Active Lifestyle": 0.8 },
  },
  {
    id: "social",
    name: "Social Media",
    icon: Users,
    cpm: 5,
    reach: "Viral",
    description: "Engagement focused, younger demographics",
    effectiveness: { Budget: 0.7, General: 0.75, Enthusiast: 0.9, Professional: 0.5, "Active Lifestyle": 0.85 },
  },
  {
    id: "print",
    name: "Print Media",
    icon: Star,
    cpm: 15,
    reach: "Niche",
    description: "Premium positioning, older demographics",
    effectiveness: { Budget: 0.3, General: 0.5, Enthusiast: 0.4, Professional: 0.8, "Active Lifestyle": 0.4 },
  },
];

const promotionTypes = [
  {
    id: "discount",
    name: "Price Discount",
    icon: Percent,
    description: "Temporary price reduction",
    costType: "% of revenue",
    effect: "Increases sales volume, may reduce brand value",
  },
  {
    id: "bundle",
    name: "Product Bundle",
    icon: Gift,
    description: "Combine products at special price",
    costType: "Fixed cost",
    effect: "Increases average order value",
  },
  {
    id: "loyalty",
    name: "Loyalty Program",
    icon: Award,
    description: "Reward repeat customers",
    costType: "% of sales",
    effect: "Increases customer retention",
  },
];

// Segment price ranges from market simulation engine
const SEGMENT_PRICE_RANGES: Record<string, { min: number; max: number }> = {
  Budget: { min: 100, max: 300 },
  General: { min: 300, max: 600 },
  Enthusiast: { min: 600, max: 1000 },
  Professional: { min: 1000, max: 1500 },
  "Active Lifestyle": { min: 400, max: 800 },
};

export default function MarketingPage({ params }: PageProps) {
  const { gameId } = use(params);
  const [activeTab, setActiveTab] = useState("overview");
  const tutorialStep = useTutorialStore(s => s.isActive ? s.steps[s.currentStep] : null);
  useEffect(() => {
    if (tutorialStep?.targetTab) setActiveTab(tutorialStep.targetTab);
  }, [tutorialStep?.targetTab]);

  // Get decisions from store
  const { marketing, setMarketingDecisions, submissionStatus } = useDecisionStore();

  // Show completion toast after Marketing save (final module)
  const prevMarketingSubmittedRef = useRef(submissionStatus.MARKETING?.isSubmitted);
  useEffect(() => {
    const wasSubmitted = prevMarketingSubmittedRef.current;
    const isNowSubmitted = submissionStatus.MARKETING?.isSubmitted;
    prevMarketingSubmittedRef.current = isNowSubmitted;

    if (!wasSubmitted && isNowSubmitted) {
      toast.success("All decisions submitted! Your round is ready to advance.", {
        duration: 6000,
      });
    }
  }, [submissionStatus.MARKETING?.isSubmitted]);

  // Decision states (synced with store)
  const [adBudgets, setAdBudgets] = useState<Record<string, Record<string, number>>>(
    marketing.adBudgets && Object.keys(marketing.adBudgets).length > 0
      ? marketing.adBudgets
      : {
          Budget: { tv: 0, digital: 0, social: 0, print: 0 },
          General: { tv: 0, digital: 0, social: 0, print: 0 },
          Enthusiast: { tv: 0, digital: 0, social: 0, print: 0 },
          Professional: { tv: 0, digital: 0, social: 0, print: 0 },
          "Active Lifestyle": { tv: 0, digital: 0, social: 0, print: 0 },
        }
  );
  const [brandInvestment, setBrandInvestment] = useState(marketing.brandInvestment);
  const [selectedPromotion, setSelectedPromotion] = useState<string | null>(null);
  const [promotionIntensity, setPromotionIntensity] = useState(0);
  const [purchasedBrandActivities, setPurchasedBrandActivities] = useState<string[]>(
    marketing.brandActivities?.length > 0 ? marketing.brandActivities : []
  );
  const [activePromotions, setActivePromotions] = useState<Array<{ type: string; intensity: number }>>([]);
  const [productPricing, setProductPricing] = useState<Record<string, number>>(
    marketing.productPricing && Object.keys(marketing.productPricing).length > 0
      ? marketing.productPricing
      : {}
  );

  // Sync store changes to local state (for when decisions are loaded from server)
  useEffect(() => {
    if (marketing.adBudgets && Object.keys(marketing.adBudgets).length > 0 &&
        JSON.stringify(marketing.adBudgets) !== JSON.stringify(adBudgets)) {
      setAdBudgets(marketing.adBudgets);
    }
  }, [marketing.adBudgets]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (marketing.brandInvestment !== brandInvestment) {
      setBrandInvestment(marketing.brandInvestment);
    }
  }, [marketing.brandInvestment]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (marketing.promotions && marketing.promotions.length > 0 &&
        JSON.stringify(marketing.promotions) !== JSON.stringify(activePromotions)) {
      setActivePromotions(marketing.promotions);
    }
  }, [marketing.promotions]); // eslint-disable-line react-hooks/exhaustive-deps

  // Sync store → local for brand activities
  useEffect(() => {
    if (marketing.brandActivities && marketing.brandActivities.length > 0 &&
        JSON.stringify(marketing.brandActivities) !== JSON.stringify(purchasedBrandActivities)) {
      setPurchasedBrandActivities(marketing.brandActivities);
    }
  }, [marketing.brandActivities]); // eslint-disable-line react-hooks/exhaustive-deps

  // Sync local state changes to store
  useEffect(() => {
    setMarketingDecisions({ adBudgets });
  }, [adBudgets, setMarketingDecisions]);

  useEffect(() => {
    setMarketingDecisions({ brandInvestment });
  }, [brandInvestment, setMarketingDecisions]);

  // Sync promotions to store
  useEffect(() => {
    setMarketingDecisions({ promotions: activePromotions });
  }, [activePromotions, setMarketingDecisions]);

  // Sync brand activities to store
  useEffect(() => {
    setMarketingDecisions({ brandActivities: purchasedBrandActivities });
  }, [purchasedBrandActivities, setMarketingDecisions]);

  // Sync store → local for product pricing
  useEffect(() => {
    if (marketing.productPricing && Object.keys(marketing.productPricing).length > 0 &&
        JSON.stringify(marketing.productPricing) !== JSON.stringify(productPricing)) {
      setProductPricing(marketing.productPricing);
    }
  }, [marketing.productPricing]); // eslint-disable-line react-hooks/exhaustive-deps

  // Sync product pricing to store
  useEffect(() => {
    setMarketingDecisions({ productPricing });
  }, [productPricing, setMarketingDecisions]);

  // Handle brand activity purchase
  const handlePurchaseBrandActivity = (activityId: string) => {
    setPurchasedBrandActivities(prev => [...prev, activityId]);
  };

  // Handle launch promotion
  const handleLaunchPromotion = () => {
    if (selectedPromotion && promotionIntensity > 0) {
      setActivePromotions(prev => [...prev, { type: selectedPromotion, intensity: promotionIntensity }]);
      setSelectedPromotion(null);
      setPromotionIntensity(0);
    }
  };

  // Get current decisions for submission
  const getDecisions = useCallback(() => ({
    adBudgets,
    brandInvestment,
    promotions: marketing.promotions,
    productPricing,
  }), [adBudgets, brandInvestment, marketing.promotions, productPricing]);

  const { data: teamState, isLoading } = trpc.team.getMyState.useQuery();

  // Parse team state
  const state: TeamState | null = useMemo(() => {
    if (!teamState?.state) return null;
    try {
      return typeof teamState.state === 'string'
        ? JSON.parse(teamState.state) as TeamState
        : teamState.state as TeamState;
    } catch {
      return null;
    }
  }, [teamState?.state]);

  // Fetch competitor rankings from performance history
  const { data: perfHistory } = trpc.team.getPerformanceHistory.useQuery(
    undefined,
    { enabled: !!teamState?.game }
  );

  // Compute launched products for pricing section
  const launchedProducts = useMemo(() => {
    if (!state?.products) return [];
    return state.products.filter(p => p.developmentStatus === "launched");
  }, [state?.products]);

  // Parse market state for segment demand data
  const marketState = useMemo(() => {
    if (!teamState?.marketState) return null;
    try {
      return typeof teamState.marketState === 'string'
        ? JSON.parse(teamState.marketState)
        : teamState.marketState;
    } catch {
      return null;
    }
  }, [teamState?.marketState]);

  // Cross-module warnings
  const marketingWarnings = useCrossModuleWarnings(state, "marketing");

  // Preview hook for live impact
  const marketingPreview = useMarketingPreview(state, marketing);

  // Compute marketing data from state
  const marketingData = useMemo(() => {
    if (!state) return defaultMarketing;

    // Calculate total market share from all segments
    const marketShareEntries = state.marketShare ? Object.values(state.marketShare) : [];
    const totalMarketShare = marketShareEntries.length > 0
      ? marketShareEntries.reduce((sum, share) => sum + share, 0) / marketShareEntries.length
      : 0;

    // Brand awareness derived from brand value (higher brand = more awareness)
    const brandAwareness = Math.min(100, (state.brandValue || 0.5) * 100 + 10);

    // Customer satisfaction derived from product quality and workforce morale
    const avgProductQuality = state.products && state.products.length > 0
      ? state.products.reduce((sum, p) => sum + (p.quality || 0), 0) / state.products.length
      : 50;
    const workforceMorale = state.workforce?.averageMorale || 70;
    const customerSatisfaction = Math.round((avgProductQuality + workforceMorale) / 2);

    return {
      brandValue: state.brandValue || defaultMarketing.brandValue,
      brandAwareness: Math.round(brandAwareness),
      marketShare: totalMarketShare,
      customerSatisfaction,
    };
  }, [state]);

  // Compute segment-specific market share data
  const segmentMarketShare = useMemo((): Partial<Record<Segment, number>> => {
    if (!state?.marketShare) return {};
    return state.marketShare;
  }, [state?.marketShare]);

  // Get segment demand from market state
  const segmentDemand = useMemo(() => {
    if (!marketState?.demandBySegment) return {};
    return marketState.demandBySegment;
  }, [marketState?.demandBySegment]);

  const getTotalAdBudget = () => {
    return Object.values(adBudgets).reduce((total, segment) => {
      return total + Object.values(segment).reduce((sum, val) => sum + val, 0);
    }, 0);
  };

  const getSegmentBudget = (segmentId: string) => {
    return Object.values(adBudgets[segmentId] || {}).reduce((sum, val) => sum + val, 0);
  };

  if (isLoading) return <GamePageSkeleton statCards={4} sections={2} />;

  const currentRound = teamState?.game?.currentRound ?? 1;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Page Header */}
      <PageHeader
        title="Marketing"
        subtitle="Manage advertising campaigns, brand value, and promotions"
        icon={<Megaphone className="w-7 h-7" />}
        iconColor="text-pink-400"
      />

      {/* Last round recap */}
      <ModuleRecap module="marketing" currentRound={currentRound} state={state} history={[]} />

      {/* Cross-module warnings */}
      <WarningBanner warnings={marketingWarnings} />

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-slate-800 border-slate-700">
          <TabsTrigger value="overview" className="data-[state=active]:bg-slate-700">
            Overview
          </TabsTrigger>
          <TabsTrigger value="pricing" className="data-[state=active]:bg-slate-700">
            Pricing
          </TabsTrigger>
          <TabsTrigger value="advertising" className="data-[state=active]:bg-slate-700">
            Advertising
          </TabsTrigger>
          <TabsTrigger value="brand" className="data-[state=active]:bg-slate-700">
            Brand
          </TabsTrigger>
          <TabsTrigger value="promotions" className="data-[state=active]:bg-slate-700">
            Promotions
          </TabsTrigger>
          <TabsTrigger value="intelligence" className="data-[state=active]:bg-slate-700">
            Intelligence
          </TabsTrigger>
          <TabsTrigger value="segments" className="data-[state=active]:bg-slate-700">
            Segments
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Key Metrics */}
          {(() => {
            const previewBrand = marketingPreview.previewState?.brandValue;
            const currentBrand = marketingData.brandValue;
            const brandChange = previewBrand != null ? previewBrand - currentBrand : 0;
            return (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <StatCard
                  label="Brand Value"
                  value={`${(currentBrand * 100).toFixed(0)}%${brandChange !== 0 ? ` (${brandChange > 0 ? "+" : ""}${(brandChange * 100).toFixed(1)}%)` : ""}`}
                  icon={<Award className="w-5 h-5" />}
                  variant="pink"
                />
                <StatCard
                  label="Brand Awareness"
                  value={`${marketingData.brandAwareness}%`}
                  icon={<Target className="w-5 h-5" />}
                  variant="info"
                />
                <StatCard
                  label="Market Share"
                  value={`${(marketingData.marketShare * 100).toFixed(1)}%`}
                  icon={<BarChart3 className="w-5 h-5" />}
                  variant="success"
                />
                <StatCard
                  label="Customer Satisfaction"
                  value={`${marketingData.customerSatisfaction}%`}
                  icon={<Star className="w-5 h-5" />}
                  variant="purple"
                />
              </div>
            );
          })()}

          {/* Marketing Overview */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-slate-800/80 border-slate-700/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Award className="w-5 h-5 text-pink-400" />
                  Brand Performance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-5">
                <EnhancedProgress
                  value={marketingData.brandValue * 100}
                  variant="pink"
                  size="md"
                  showLabel
                  showValue
                  label="Brand Value"
                  formatValue={(v) => `${v.toFixed(0)}%`}
                />
                <EnhancedProgress
                  value={marketingData.brandAwareness}
                  variant="info"
                  size="md"
                  showLabel
                  showValue
                  label="Brand Awareness"
                  formatValue={(v) => `${v}%`}
                />
                <EnhancedProgress
                  value={marketingData.customerSatisfaction}
                  variant="purple"
                  size="md"
                  showLabel
                  showValue
                  label="Customer Satisfaction"
                  formatValue={(v) => `${v}%`}
                />
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Marketing Budget Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                  <span className="text-slate-300">Total Ad Budget</span>
                  <span className="text-white font-medium">{formatCurrency(getTotalAdBudget())}</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                  <span className="text-slate-300">Brand Investment</span>
                  <span className="text-white font-medium">{formatCurrency(brandInvestment)}</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-pink-900/30 border border-pink-700 rounded-lg">
                  <span className="text-pink-400">Total Marketing Spend</span>
                  <span className="text-pink-400 font-medium">
                    {formatCurrency(getTotalAdBudget() + brandInvestment)}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Current Round Marketing Decisions */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-pink-400" />
                Current Round Decisions
              </CardTitle>
              <CardDescription className="text-slate-400">
                Summary of all marketing decisions for this round
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Advertising Section */}
              {getTotalAdBudget() > 0 && (
                <div>
                  <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">Advertising</p>
                  <div className="space-y-2">
                    {Object.entries(adBudgets).map(([segment, channels]) => {
                      const segmentTotal = Object.values(channels).reduce((s, v) => s + v, 0);
                      if (segmentTotal === 0) return null;
                      return (
                        <div key={segment} className="p-3 bg-slate-700/50 rounded-lg">
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-white font-medium text-sm">{segment}</span>
                            <span className="text-pink-400 font-medium text-sm">{formatCurrency(segmentTotal)}</span>
                          </div>
                          <div className="flex gap-2 flex-wrap">
                            {Object.entries(channels).map(([channel, amount]) => {
                              if (amount === 0) return null;
                              const channelName = advertisingChannels.find(c => c.id === channel)?.name ?? channel;
                              return (
                                <Badge key={channel} className="bg-slate-600/50 text-slate-300 text-xs">
                                  {channelName}: {formatCurrency(amount)}
                                </Badge>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Brand Investment Section */}
              {brandInvestment > 0 && (
                <div>
                  <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">Brand Investment</p>
                  <div className="p-3 bg-pink-900/20 border border-pink-700/30 rounded-lg">
                    <div className="flex justify-between items-center">
                      <span className="text-white font-medium text-sm">Direct Brand Investment</span>
                      <span className="text-pink-400 font-medium">{formatCurrency(brandInvestment)}</span>
                    </div>
                    <p className="text-slate-400 text-xs mt-1">
                      Projected brand increase: +{(brandInvestment / 10_000_000 * 5).toFixed(1)}%
                    </p>
                  </div>
                </div>
              )}

              {/* Brand Activities Section */}
              {purchasedBrandActivities.length > 0 && (
                <div>
                  <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">Brand Activities</p>
                  <div className="space-y-2">
                    {purchasedBrandActivities.map(activityId => {
                      const activity = BRAND_ACTIVITY_MAP[activityId];
                      if (!activity) return null;
                      return (
                        <div key={activityId} className="flex justify-between items-center p-3 bg-green-900/20 border border-green-700/30 rounded-lg">
                          <div>
                            <p className="text-white font-medium text-sm">{activity.name}</p>
                            <p className="text-green-400 text-xs">+{(activity.brandImpact * 100).toFixed(0)}% brand impact</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-emerald-400 font-medium text-sm">{formatCurrency(activity.cost)}</span>
                            <Button
                              size="sm"
                              variant="destructive"
                              className="h-6 px-2 text-xs"
                              onClick={() => setPurchasedBrandActivities(prev => prev.filter(id => id !== activityId))}
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Promotions Section */}
              {activePromotions.length > 0 && (
                <div>
                  <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">Promotions</p>
                  <div className="space-y-2">
                    {activePromotions.map((promo, idx) => (
                      <div key={idx} className="flex justify-between items-center p-3 bg-slate-700/50 rounded-lg">
                        <span className="text-white text-sm">{promo.type}</span>
                        <Badge className="bg-pink-500/20 text-pink-400 text-xs">{promo.intensity}% intensity</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Empty state */}
              {getTotalAdBudget() === 0 && brandInvestment === 0 && purchasedBrandActivities.length === 0 && activePromotions.length === 0 && (
                <div className="text-center py-8 text-slate-400">
                  <Megaphone className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No marketing decisions set</p>
                  <p className="text-sm mt-1">
                    Use the <button className="text-pink-400 underline" onClick={() => setActiveTab("advertising")}>Advertising</button> or{" "}
                    <button className="text-pink-400 underline" onClick={() => setActiveTab("brand")}>Brand</button> tabs to allocate budgets
                  </p>
                </div>
              )}

              {/* Total Cost Summary */}
              {(getTotalAdBudget() > 0 || brandInvestment > 0 || purchasedBrandActivities.length > 0) && (
                <div className="pt-3 border-t border-slate-700">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 text-sm font-medium">Total Marketing Cost</span>
                    <span className="text-pink-400 font-bold text-lg">
                      {formatCurrency(
                        getTotalAdBudget() + brandInvestment +
                        purchasedBrandActivities.reduce((sum, id) => sum + (BRAND_ACTIVITY_MAP[id]?.cost ?? 0), 0)
                      )}
                    </span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pricing Tab */}
        <TabsContent value="pricing" className="space-y-6">
          <Card className="bg-slate-800/80 border-slate-700/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-pink-400" />
                Product Pricing
                <HelpTooltip text="Set prices for your launched products. Each segment has a recommended price range. Pricing below unit cost means selling at a loss." />
              </CardTitle>
              <CardDescription className="text-slate-400">
                Adjust prices for your launched products to maximize revenue and market share
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {launchedProducts.length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  <ShoppingCart className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No launched products</p>
                  <p className="text-sm mt-1">Launch products from R&D to set their prices here</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {launchedProducts.map((product) => {
                    const priceRange = SEGMENT_PRICE_RANGES[product.segment] || { min: 100, max: 1000 };
                    const currentPrice = productPricing[product.id] ?? product.price;
                    const margin = product.unitCost > 0
                      ? ((currentPrice - product.unitCost) / currentPrice * 100)
                      : 0;
                    const isBelowCost = currentPrice < product.unitCost;

                    return (
                      <div key={product.id} className={`p-4 rounded-lg border ${isBelowCost ? 'bg-red-900/20 border-red-700/50' : 'bg-slate-700/30 border-slate-600/50'}`}>
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <span className="text-white font-medium">{product.name}</span>
                            <Badge className="bg-pink-500/20 text-pink-300 text-xs">{product.segment}</Badge>
                            {product.qualityGrade && product.qualityGrade !== "standard" && (
                              <Badge className="bg-purple-500/20 text-purple-300 text-xs">{product.qualityGrade}</Badge>
                            )}
                          </div>
                          <div className="text-right">
                            <div className="text-white font-bold text-lg">${currentPrice.toFixed(0)}</div>
                            <div className={`text-xs ${margin >= 30 ? 'text-green-400' : margin >= 10 ? 'text-yellow-400' : 'text-red-400'}`}>
                              {margin.toFixed(1)}% margin
                            </div>
                          </div>
                        </div>

                        {/* Unit cost and suggested range */}
                        <div className="grid grid-cols-3 gap-3 mb-3 text-sm">
                          <div className="p-2 bg-slate-800/50 rounded">
                            <span className="text-slate-400 text-xs block">Unit Cost</span>
                            <span className="text-white font-medium">${product.unitCost.toFixed(0)}</span>
                          </div>
                          <div className="p-2 bg-slate-800/50 rounded">
                            <span className="text-slate-400 text-xs block">Suggested Range</span>
                            <span className="text-white font-medium">${priceRange.min} - ${priceRange.max}</span>
                          </div>
                          <div className="p-2 bg-slate-800/50 rounded">
                            <span className="text-slate-400 text-xs block">Original Price</span>
                            <span className="text-slate-300 font-medium">${product.price.toFixed(0)}</span>
                          </div>
                        </div>

                        {/* Below cost warning */}
                        {isBelowCost && (
                          <div className="flex items-center gap-2 p-2 bg-red-900/30 border border-red-700/50 rounded mb-3">
                            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                            <span className="text-red-400 text-sm font-medium">Selling below cost! Loss of ${(product.unitCost - currentPrice).toFixed(0)} per unit</span>
                          </div>
                        )}

                        {/* Price input + slider */}
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <span className="text-slate-400 text-sm shrink-0">Set Price</span>
                            <Input
                              type="number"
                              min={0}
                              max={priceRange.max * 2}
                              step={5}
                              value={currentPrice}
                              onChange={(e) => {
                                const value = Math.max(0, Number(e.target.value) || 0);
                                setProductPricing(prev => ({ ...prev, [product.id]: value }));
                              }}
                              className="w-28 h-8 text-right bg-slate-700 border-slate-600 text-pink-400 font-semibold"
                            />
                          </div>
                          <Slider
                            value={[currentPrice]}
                            onValueChange={(values) => {
                              setProductPricing(prev => ({ ...prev, [product.id]: values[0] }));
                            }}
                            min={Math.max(0, priceRange.min * 0.5)}
                            max={priceRange.max * 1.5}
                            step={5}
                            variant="default"
                          />
                          <div className="flex justify-between text-xs text-slate-500">
                            <span>${Math.round(priceRange.min * 0.5)}</span>
                            <span className="text-slate-400">${priceRange.min} - ${priceRange.max} suggested</span>
                            <span>${Math.round(priceRange.max * 1.5)}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  {/* Summary */}
                  {Object.keys(productPricing).length > 0 && (
                    <div className="p-3 bg-pink-900/20 border border-pink-700/30 rounded-lg">
                      <p className="text-pink-400 text-sm font-medium mb-2">Pricing Changes This Round</p>
                      <div className="space-y-1">
                        {launchedProducts
                          .filter(p => productPricing[p.id] !== undefined && productPricing[p.id] !== p.price)
                          .map(p => {
                            const newPrice = productPricing[p.id]!;
                            const diff = newPrice - p.price;
                            return (
                              <div key={p.id} className="flex justify-between items-center text-sm">
                                <span className="text-white">{p.name}</span>
                                <span className={diff >= 0 ? 'text-green-400' : 'text-red-400'}>
                                  ${p.price.toFixed(0)} → ${newPrice.toFixed(0)} ({diff >= 0 ? '+' : ''}{diff.toFixed(0)})
                                </span>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Advertising Tab */}
        <TabsContent value="advertising" className="space-y-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Advertising Budget Allocation <HelpTooltip text="Diminishing returns above $3M per segment. Focus on segments you're actively selling in. Digital and Social have higher reach per dollar." /></CardTitle>
              <CardDescription className="text-slate-400">
                Allocate advertising budget across channels and market segments
              </CardDescription>
              {/* H5 FIX: Quick Allocate — only targets segments player has products in */}
              {(() => {
                // Determine which segments the player is active in
                const activeSegs = state?.products
                  ?.filter((p) => p.developmentStatus === "launched" || p.developmentStatus === "ready")
                  .map((p) => p.segment)
                  .filter((v, i, a) => a.indexOf(v) === i) ?? [];
                const targetSegs = activeSegs.length > 0
                  ? activeSegs
                  : ["Budget", "General"]; // fallback to starter segments

                const quickAllocate = (totalBudget: number) => {
                  const perSegment = totalBudget / targetSegs.length;
                  const perChannel = perSegment / 4;
                  const quickBudgets: Record<string, Record<string, number>> = {};
                  // Zero out all segments first
                  for (const seg of ["Budget", "General", "Enthusiast", "Professional", "Active Lifestyle"]) {
                    quickBudgets[seg] = { tv: 0, digital: 0, social: 0, print: 0 };
                  }
                  // Allocate only to active segments
                  for (const seg of targetSegs) {
                    quickBudgets[seg] = {
                      tv: Math.round(perChannel),
                      digital: Math.round(perChannel * 1.2),
                      social: Math.round(perChannel * 0.9),
                      print: Math.round(perChannel * 0.5),
                    };
                  }
                  setAdBudgets(quickBudgets);
                };

                return (
                  <div className="flex items-center gap-3 mt-2">
                    <button
                      type="button"
                      onClick={() => quickAllocate(5_000_000)}
                      className="px-3 py-1.5 bg-pink-600/20 hover:bg-pink-600/30 text-pink-300 text-xs font-medium rounded-lg border border-pink-500/30 transition-colors"
                    >
                      Quick Allocate $5M
                    </button>
                    <button
                      type="button"
                      onClick={() => quickAllocate(10_000_000)}
                      className="px-3 py-1.5 bg-pink-600/20 hover:bg-pink-600/30 text-pink-300 text-xs font-medium rounded-lg border border-pink-500/30 transition-colors"
                    >
                      Quick Allocate $10M
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const resetBudgets: Record<string, Record<string, number>> = {};
                        for (const seg of ["Budget", "General", "Enthusiast", "Professional", "Active Lifestyle"]) {
                          resetBudgets[seg] = { tv: 0, digital: 0, social: 0, print: 0 };
                        }
                        setAdBudgets(resetBudgets);
                      }}
                      className="px-3 py-1.5 bg-slate-600/20 hover:bg-slate-600/30 text-slate-400 text-xs font-medium rounded-lg border border-slate-500/30 transition-colors"
                    >
                      Clear All
                    </button>
                    {activeSegs.length > 0 && (
                      <span className="text-slate-500 text-xs">
                        Targeting: {targetSegs.join(", ")}
                      </span>
                    )}
                  </div>
                );
              })()}
            </CardHeader>
            <CardContent>
              {/* Scrollable container for mobile */}
              <div className="overflow-x-auto -mx-4 px-4 md:mx-0 md:px-0">
                <div className="min-w-[600px]">
                  {/* Channel Headers */}
                  <div className="grid grid-cols-5 gap-4 mb-4 text-center">
                    <div></div>
                    {advertisingChannels.map((channel) => (
                      <div key={channel.id} className="p-2 bg-slate-700/50 rounded-lg">
                        <channel.icon className="w-5 h-5 mx-auto mb-1 text-slate-400" />
                        <span className="text-slate-300 text-sm">{channel.name}</span>
                        <div className="text-xs text-slate-500" title="Cost per 1,000 impressions">${channel.cpm} Cost per 1K impressions</div>
                      </div>
                    ))}
                  </div>

                  {/* Segment Rows */}
                  {segments.map((segment) => (
                    <div key={segment.id} className="grid grid-cols-5 gap-4 mb-4 items-center">
                      <div className="p-2">
                        <span className="text-white font-medium">{segment.name}</span>
                        <div className="text-xs text-slate-400">{segment.description}</div>
                      </div>
                      {advertisingChannels.map((channel) => (
                        <div key={channel.id}>
                          <input
                            type="number"
                            min="0"
                            max="10000000"
                            step="50000"
                            data-testid={`input-ad-${segment.id}-${channel.id}`}
                            value={adBudgets[segment.id]?.[channel.id] || 0}
                            onChange={(e) => {
                              const value = Math.max(0, parseInt(e.target.value) || 0);
                              setAdBudgets(prev => ({
                                ...prev,
                                [segment.id]: {
                                  ...prev[segment.id],
                                  [channel.id]: value,
                                },
                              }));
                            }}
                            className="w-full bg-slate-700 border-slate-600 rounded px-2 py-1 text-white text-sm text-center"
                            placeholder="$0"
                          />
                          <div className="text-xs text-center mt-1">
                            <span className={`${
                              channel.effectiveness[segment.id as keyof typeof channel.effectiveness] >= 0.8
                                ? 'text-green-400'
                                : channel.effectiveness[segment.id as keyof typeof channel.effectiveness] >= 0.6
                                ? 'text-yellow-400'
                                : 'text-slate-500'
                            }`}>
                              {Math.round(channel.effectiveness[segment.id as keyof typeof channel.effectiveness] * 100)}% eff
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ))}

                  {/* Summary */}
                  <div className="border-t border-slate-700 pt-4 mt-4">
                    <div className="grid grid-cols-5 gap-4">
                      <div className="text-slate-400 font-medium">Total</div>
                      {advertisingChannels.map((channel) => {
                        const channelTotal = segments.reduce(
                          (sum, seg) => sum + (adBudgets[seg.id]?.[channel.id] || 0),
                          0
                        );
                        return (
                          <div key={channel.id} className="text-center text-white font-medium">
                            {formatCurrency(channelTotal)}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-between items-center mt-4 p-3 bg-pink-900/30 border border-pink-700 rounded-lg">
                <span className="text-pink-400 font-medium">Total Advertising Budget</span>
                <span className="text-pink-400 text-xl font-bold">{formatCurrency(getTotalAdBudget())}</span>
              </div>
            </CardContent>
          </Card>

          {/* Channel Info */}
          <div className="grid md:grid-cols-4 gap-4">
            {advertisingChannels.map((channel) => (
              <Card key={channel.id} className="bg-slate-800 border-slate-700">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <channel.icon className="w-5 h-5 text-slate-400" />
                    <span className="text-white font-medium">{channel.name}</span>
                  </div>
                  <p className="text-slate-400 text-sm mb-3">{channel.description}</p>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-400" title="Cost per 1,000 impressions">Cost per 1K impressions</span>
                      <span className="text-white">${channel.cpm}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Reach</span>
                      <span className="text-white">{channel.reach}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Brand Tab */}
        <TabsContent value="brand" className="space-y-6">
          <Card className="bg-slate-800/80 border-slate-700/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-pink-400" />
                Brand Investment
                <HelpTooltip text="Brand value decays 2% per round without investment. Higher brand = more market share and premium pricing. 5% increase per $10M invested." />
              </CardTitle>
              <CardDescription className="text-slate-400">
                Invest in brand-building activities to increase brand value and premium pricing power.
                <span className="text-pink-400"> 5% brand value increase per $10M invested.</span>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-4 bg-slate-700/30 rounded-lg space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-slate-300 font-medium">Investment Amount</span>
                  <Input
                    type="number"
                    value={brandInvestment}
                    onChange={(e) => setBrandInvestment(Math.max(0, Math.min(50000000, Number(e.target.value) || 0)))}
                    className="w-36 h-8 text-right bg-slate-700 border-slate-600 text-pink-400 font-semibold"
                  />
                </div>
                <Slider
                  data-testid="slider-brand-investment"
                  value={[brandInvestment]}
                  onValueChange={(values) => setBrandInvestment(values[0])}
                  max={50000000}
                  step={500000}
                  variant="default"
                />
                <div className="flex justify-between text-xs text-slate-400">
                  <span>$0</span>
                  <span>$50M</span>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div className="p-4 bg-slate-700/50 rounded-lg text-center">
                  <div className="text-slate-400 text-sm mb-1">Current Brand Value</div>
                  <div className="text-2xl font-bold text-white">
                    {(marketingData.brandValue * 100).toFixed(0)}%
                  </div>
                </div>
                <div className="p-4 bg-slate-700/50 rounded-lg text-center">
                  <div className="text-slate-400 text-sm mb-1">Projected Increase</div>
                  <div className="text-2xl font-bold text-green-400">
                    +{(brandInvestment / 10_000_000 * 5).toFixed(1)}%
                  </div>
                </div>
                <div className="p-4 bg-pink-900/30 border border-pink-700 rounded-lg text-center">
                  <div className="text-pink-400 text-sm mb-1">Projected Brand Value</div>
                  <div className="text-2xl font-bold text-pink-400">
                    {Math.min(100, marketingData.brandValue * 100 + brandInvestment / 10_000_000 * 5).toFixed(0)}%
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Brand Activities */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Brand Building Activities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className={`p-4 rounded-lg ${purchasedBrandActivities.includes('celebrity') ? 'bg-green-900/30 border border-green-700' : 'bg-slate-700/50'}`}>
                  <h3 className="text-white font-medium mb-2">Celebrity Endorsement</h3>
                  <p className="text-slate-400 text-sm mb-3">
                    Partner with celebrities to boost brand recognition
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-green-400">+10% awareness</span>
                    <span className="text-white">{formatCurrency(15_000_000)}</span>
                  </div>
                  {purchasedBrandActivities.includes('celebrity') ? (
                    <Button size="sm" className="w-full mt-3 bg-green-600" disabled>
                      Purchased
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      className="w-full mt-3 bg-pink-600 hover:bg-pink-700"
                      onClick={() => handlePurchaseBrandActivity('celebrity')}
                    >
                      Purchase
                    </Button>
                  )}
                </div>
                <div className={`p-4 rounded-lg ${purchasedBrandActivities.includes('sponsorship') ? 'bg-green-900/30 border border-green-700' : 'bg-slate-700/50'}`}>
                  <h3 className="text-white font-medium mb-2">Major Event Sponsorship</h3>
                  <p className="text-slate-400 text-sm mb-3">
                    Sponsor major sporting or cultural events
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-green-400">+8% awareness, +3% brand value</span>
                    <span className="text-white">{formatCurrency(20_000_000)}</span>
                  </div>
                  {purchasedBrandActivities.includes('sponsorship') ? (
                    <Button size="sm" className="w-full mt-3 bg-green-600" disabled>
                      Purchased
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      className="w-full mt-3 bg-pink-600 hover:bg-pink-700"
                      onClick={() => handlePurchaseBrandActivity('sponsorship')}
                    >
                      Purchase
                    </Button>
                  )}
                </div>
                <div className={`p-4 rounded-lg ${purchasedBrandActivities.includes('csr') ? 'bg-green-900/30 border border-green-700' : 'bg-slate-700/50'}`}>
                  <h3 className="text-white font-medium mb-2">CSR Initiative</h3>
                  <p className="text-slate-400 text-sm mb-3">
                    Launch corporate social responsibility programs
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-green-400">+5% brand value, +50 ESG</span>
                    <span className="text-white">{formatCurrency(10_000_000)}</span>
                  </div>
                  {purchasedBrandActivities.includes('csr') ? (
                    <Button size="sm" className="w-full mt-3 bg-green-600" disabled>
                      Purchased
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      className="w-full mt-3 bg-pink-600 hover:bg-pink-700"
                      onClick={() => handlePurchaseBrandActivity('csr')}
                    >
                      Purchase
                    </Button>
                  )}
                </div>
                <div className={`p-4 rounded-lg ${purchasedBrandActivities.includes('refresh') ? 'bg-green-900/30 border border-green-700' : 'bg-slate-700/50'}`}>
                  <h3 className="text-white font-medium mb-2">Brand Refresh</h3>
                  <p className="text-slate-400 text-sm mb-3">
                    Update visual identity and brand messaging
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-green-400">+7% brand value</span>
                    <span className="text-white">{formatCurrency(8_000_000)}</span>
                  </div>
                  {purchasedBrandActivities.includes('refresh') ? (
                    <Button size="sm" className="w-full mt-3 bg-green-600" disabled>
                      Purchased
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      className="w-full mt-3 bg-pink-600 hover:bg-pink-700"
                      onClick={() => handlePurchaseBrandActivity('refresh')}
                    >
                      Purchase
                    </Button>
                  )}
                </div>
              </div>
              {purchasedBrandActivities.length > 0 && (
                <div className="mt-4 p-4 bg-green-900/20 border border-green-700 rounded-lg space-y-2">
                  <p className="text-green-400 text-sm font-medium mb-2">Pending Brand Activities</p>
                  {purchasedBrandActivities.map(activityId => {
                    const activity = BRAND_ACTIVITY_MAP[activityId];
                    if (!activity) return null;
                    return (
                      <div key={activityId} className="flex justify-between items-center p-2 bg-green-900/30 rounded">
                        <div>
                          <span className="text-white text-sm font-medium">{activity.name}</span>
                          <span className="text-green-400 text-xs ml-2">+{(activity.brandImpact * 100).toFixed(0)}% brand</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-emerald-400 text-sm">{formatCurrency(activity.cost)}</span>
                          <Button
                            size="sm"
                            variant="destructive"
                            className="h-6 px-2 text-xs"
                            onClick={() => setPurchasedBrandActivities(prev => prev.filter(id => id !== activityId))}
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                  <div className="flex justify-between items-center pt-2 border-t border-green-700/50">
                    <span className="text-slate-400 text-sm">Total Activities Cost</span>
                    <span className="text-emerald-400 font-bold">
                      {formatCurrency(purchasedBrandActivities.reduce((sum, id) => sum + (BRAND_ACTIVITY_MAP[id]?.cost ?? 0), 0))}
                    </span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Promotions Tab */}
        <TabsContent value="promotions" className="space-y-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Gift className="w-5 h-5" />
                Sales Promotions
              </CardTitle>
              <CardDescription className="text-slate-400">
                Run promotional campaigns to boost short-term sales
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                {promotionTypes.map((promo) => (
                  <Card
                    key={promo.id}
                    className={`bg-slate-700 border-slate-600 cursor-pointer transition-all ${
                      selectedPromotion === promo.id ? 'border-pink-500 ring-2 ring-pink-500/20' : 'hover:border-slate-500'
                    }`}
                    onClick={() => setSelectedPromotion(promo.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <promo.icon className="w-5 h-5 text-pink-400" />
                        <span className="text-white font-medium">{promo.name}</span>
                      </div>
                      <p className="text-slate-400 text-sm mb-3">{promo.description}</p>
                      <div className="text-xs text-slate-500">
                        <div>Cost: {promo.costType}</div>
                        <div className="text-green-400 mt-1">{promo.effect}</div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {selectedPromotion && (
                <div className="mt-6 p-4 bg-slate-700/50 rounded-lg border border-pink-500/30">
                  <h3 className="text-white font-medium mb-4 flex items-center gap-2">
                    <Percent className="w-4 h-4 text-pink-400" />
                    Configure Promotion
                  </h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300 font-medium">Promotion Intensity</span>
                      <span className="text-pink-400 font-semibold text-lg">{promotionIntensity}%</span>
                    </div>
                    <Slider
                      value={[promotionIntensity]}
                      onValueChange={(values) => setPromotionIntensity(values[0])}
                      max={30}
                      step={1}
                      variant="default"
                    />
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>None</span>
                      <span>30% (Maximum)</span>
                    </div>
                  </div>
                  <div className="flex justify-end mt-4">
                    <Button
                      className="bg-pink-600 hover:bg-pink-700 shadow-lg shadow-pink-600/20"
                      onClick={handleLaunchPromotion}
                      disabled={promotionIntensity === 0}
                    >
                      Launch Promotion
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Active Promotions */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Active Promotions</CardTitle>
            </CardHeader>
            <CardContent>
              {activePromotions.length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  <Tag className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No active promotions</p>
                  <p className="text-sm">Launch a promotion to boost sales</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {activePromotions.map((promo, idx) => {
                    const promoType = promotionTypes.find(p => p.id === promo.type);
                    return (
                      <div key={idx} className="p-3 bg-green-900/20 border border-green-700 rounded-lg flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          {promoType && <promoType.icon className="w-5 h-5 text-green-400" />}
                          <div>
                            <span className="text-white font-medium">{promoType?.name}</span>
                            <span className="text-slate-400 text-sm ml-2">({promo.intensity}% intensity)</span>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-red-400 h-6 px-2"
                          onClick={() => setActivePromotions(prev => prev.filter((_, i) => i !== idx))}
                        >
                          Cancel
                        </Button>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Competitor Intelligence Tab */}
        <TabsContent value="intelligence" className="space-y-6">
          <Card className="bg-slate-800/80 border-slate-700/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Eye className="w-5 h-5 text-pink-400" />
                Competitor Intelligence
                <HelpTooltip text="Approximate competitor data based on market research. Numbers are estimates, not exact figures." />
              </CardTitle>
              <CardDescription className="text-slate-400">
                Market research on competitor positioning. Data is approximate and based on observable market signals.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {(!perfHistory?.currentRankings || perfHistory.currentRankings.length === 0) ? (
                <div className="text-center py-8 text-slate-400">
                  <Eye className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No competitor data available yet</p>
                  <p className="text-sm mt-1">Intelligence will be available after the first round completes</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {perfHistory.currentRankings.map((competitor) => {
                    const metrics = competitor.metrics;
                    const revenue = metrics.revenue || 0;
                    const unitsSold = metrics.unitsSold || 0;
                    const marketShare = metrics.marketShare || 0;

                    // Approximate price level from revenue/units ratio
                    const avgPrice = unitsSold > 0 ? revenue / unitsSold : 0;
                    let priceLevel = "Unknown";
                    let priceLevelColor = "text-slate-400";
                    if (avgPrice > 0) {
                      if (avgPrice < 250) { priceLevel = "Budget"; priceLevelColor = "text-blue-400"; }
                      else if (avgPrice < 550) { priceLevel = "Mid-Range"; priceLevelColor = "text-green-400"; }
                      else if (avgPrice < 900) { priceLevel = "Premium"; priceLevelColor = "text-purple-400"; }
                      else { priceLevel = "Ultra"; priceLevelColor = "text-amber-400"; }
                    }

                    // Approximate quality tier from product quality metric
                    const avgQuality = metrics.avgProductQuality || metrics.productQuality || 0;
                    let qualityTier = "Standard";
                    let qualityColor = "text-slate-300";
                    if (avgQuality >= 75) { qualityTier = "Ultra"; qualityColor = "text-amber-400"; }
                    else if (avgQuality >= 50) { qualityTier = "Premium"; qualityColor = "text-purple-400"; }

                    // Guess active segments from available metrics
                    const activeSegments: string[] = [];
                    for (const seg of ["Budget", "General", "Enthusiast", "Professional", "Active Lifestyle"]) {
                      const segKey = `marketShare_${seg}`;
                      const altKey = `ms_${seg}`;
                      if ((metrics[segKey] && metrics[segKey] > 0) || (metrics[altKey] && metrics[altKey] > 0)) {
                        activeSegments.push(seg);
                      }
                    }

                    return (
                      <div key={competitor.teamId} className="p-4 bg-slate-700/30 border border-slate-600/50 rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-3 h-3 rounded-full shrink-0"
                              style={{ backgroundColor: competitor.teamColor || '#6b7280' }}
                            />
                            <span className="text-white font-medium">{competitor.teamName}</span>
                            <Badge className="bg-slate-600/50 text-slate-300 text-xs">
                              Rank #{competitor.rank}
                            </Badge>
                          </div>
                          <div className="text-right">
                            <span className="text-slate-400 text-xs block">Est. Market Share</span>
                            <span className="text-white font-medium">{(marketShare * 100).toFixed(1)}%</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-3 text-sm">
                          <div className="p-2 bg-slate-800/50 rounded">
                            <span className="text-slate-400 text-xs block">Price Level</span>
                            <span className={`font-medium ${priceLevelColor}`}>{priceLevel}</span>
                          </div>
                          <div className="p-2 bg-slate-800/50 rounded">
                            <span className="text-slate-400 text-xs block">Quality Tier</span>
                            <span className={`font-medium ${qualityColor}`}>{qualityTier}</span>
                          </div>
                          <div className="p-2 bg-slate-800/50 rounded">
                            <span className="text-slate-400 text-xs block">Active Segments</span>
                            <span className="text-white font-medium text-xs">
                              {activeSegments.length > 0 ? activeSegments.join(", ") : "Unknown"}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  <div className="p-3 bg-slate-700/20 border border-slate-600/30 rounded-lg mt-4">
                    <p className="text-slate-500 text-xs italic text-center">
                      Data is approximate and based on market research. Price levels and quality tiers are estimates, not exact figures.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Segments Tab */}
        <TabsContent value="segments" className="space-y-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Market Segments</CardTitle>
              <CardDescription className="text-slate-400">
                Overview of market segments and your position in each
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {segments.map((segment) => {
                  const share = segmentMarketShare[segment.id as Segment] || 0;
                  const demand = segmentDemand[segment.id as Segment];
                  return (
                    <Card key={segment.id} className="bg-slate-700 border-slate-600">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-pink-500/20 flex items-center justify-center">
                              <segment.icon className="w-5 h-5 text-pink-400" />
                            </div>
                            <div>
                              <h3 className="text-white font-medium">{segment.name}</h3>
                              <p className="text-slate-400 text-sm">{segment.description}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-slate-400 text-sm">Your Market Share</div>
                            <div className="text-xl font-bold text-green-400">{(share * 100).toFixed(1)}%</div>
                          </div>
                        </div>
                        <div className="grid grid-cols-4 gap-4 mt-4 text-sm">
                          <div>
                            <span className="text-slate-400">Ad Spend</span>
                            <div className="text-white font-medium">{formatCurrency(getSegmentBudget(segment.id))}</div>
                          </div>
                          <div>
                            <span className="text-slate-400">Total Demand</span>
                            <div className="text-white font-medium">
                              {demand?.totalDemand ? `${(demand.totalDemand / 1000).toFixed(0)}K` : '--'}
                            </div>
                          </div>
                          <div>
                            <span className="text-slate-400">Price Range</span>
                            <div className="text-white font-medium">
                              {demand?.priceRange
                                ? `$${demand.priceRange.min}-$${demand.priceRange.max}`
                                : '--'}
                            </div>
                          </div>
                          <div>
                            <span className="text-slate-400">Growth</span>
                            <div className={`font-medium ${(demand?.growthRate || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                              {demand?.growthRate ? `${(demand.growthRate * 100).toFixed(1)}%` : '--'}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Decision Impact Preview */}
      <DecisionImpactPanel
        moduleName="Marketing"
        costs={marketingPreview.costs}
        messages={marketingPreview.messages}
        cashRemaining={state ? state.cash - marketingPreview.costs : undefined}
      />

      {/* Decision Submit Bar */}
      <DecisionSubmitBar module="MARKETING" getDecisions={getDecisions} />

      {/* Spacer for fixed submit bar */}
      <div className="h-20" />
    </div>
  );
}
